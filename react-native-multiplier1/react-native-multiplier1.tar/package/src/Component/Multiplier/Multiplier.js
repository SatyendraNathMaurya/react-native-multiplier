import React from 'react';

export function multiply(a, b){
    //console.log(a,b)
    return (a * b);
  }

  export function substractor(a, b){
    //console.log(a,b)
    return (a - b);
  }
  