import React from 'react';

export function adder(a, b){
    //console.log(a,b)
    return (a + b);
}