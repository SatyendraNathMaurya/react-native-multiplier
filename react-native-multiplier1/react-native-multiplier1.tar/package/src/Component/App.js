// /**
//  * Sample React Native App
//  * https://github.com/facebook/react-native
//  *
//  * @format
//  */


// import {View,} from 'react-native';
// import { adder } from './Adder/Add';
// import { multiply } from './Multiplier/Multiplier';

// function App(){

//   return (
//     <View><Text>Hello-</Text></View>
//   )

// }

//  function square(a){
//     //console.log(a,b)
//     return (a * a);
//   }


// export default {App, adder, multiply, square};
