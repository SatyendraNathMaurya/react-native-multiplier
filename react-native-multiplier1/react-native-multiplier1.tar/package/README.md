# react-native-multiplier

Demo project for library testing react-native-multiplier1

## Installation

```sh
npm install react-native-multiplier1
```

## Usage

```js
import {substractor} from 'react-native-multiplier1/src/Component/Multiplier/Multiplier.js'

import {App,square,adder,multiply} from 'react-native-multiplier1/src/index.js'

// ...

const result =  multiply(3, 7);
const result =  square(3);
const result =  adder(3, 7);
const result =  substractor(3, 7);

return(
    <App/>
)
```

## Contributing

See the [contributing guide](CONTRIBUTING.md) to learn how to contribute to the repository and the development workflow.

## License

MIT

---

Made with [create-react-native-library](https://github.com/callstack/react-native-builder-bob)
